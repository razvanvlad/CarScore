import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, CarData, FuelType } from '../types';

// Per coding guidelines, the API key must be obtained exclusively from process.env.API_KEY.
// Vite replaces this at build time with the value from the .env file.
const apiKey = process.env.API_KEY;
if (!apiKey) {
  throw new Error("API_KEY is not set in the .env file.");
}
const ai = new GoogleGenAI({ apiKey });


// This schema enforces the AI to return data in the exact format we need,
// mirroring the user's backend logic.
const carAnalysisSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: 'A realistic title for the car ad, e.g., "Volkswagen Golf 7 2.0 TDI"' },
    price: { type: Type.NUMBER, description: 'The listing price in Euros.' },
    predictedPrice: { type: Type.NUMBER, description: 'A realistic predicted market price, close to the listing price but with some variation.' },
    year: { type: Type.NUMBER, description: 'The manufacturing year of the car.' },
    kilometers: { type: Type.NUMBER, description: 'The kilometers/mileage of the car.' },
    power: { type: Type.NUMBER, description: 'The power of the car in horsepower (HP).' },
    fuel: { type: Type.STRING, enum: ['Petrol', 'Diesel', 'Electric', 'Hybrid'], description: 'The fuel type.' },
    description: { type: Type.STRING, description: 'A short, plausible ad description (2-3 sentences). Include keywords that might trigger flags if appropriate (e.g., "vopsit," "lovit," "airbag aprins").' },
    defects: { 
      type: Type.ARRAY, 
      items: { 
        type: Type.STRING, 
        enum: ['timing_chain', 'egr', 'dpf', 'clutch', 'suspension', 'turbo', 'injectors']
      },
      description: 'An array of potential mechanical defects based on the generated description.'
    },
    flags: {
      type: Type.ARRAY,
      items: {
        type: Type.STRING,
        enum: ['odo_rollback', 'accident', 'high_price', 'low_price']
      },
      description: 'An array of red flags based on the provided rules.'
    },
    score: {
      type: Type.NUMBER,
      description: 'The final score calculated based on the provided formula, clamped between 0 and 100.'
    }
  },
  required: ['title', 'price', 'predictedPrice', 'year', 'kilometers', 'power', 'fuel', 'description', 'defects', 'flags', 'score']
};

/**
 * Generates a detailed prompt that instructs the AI to simulate the entire backend analysis pipeline.
 * @param link The car listing URL to analyze.
 * @returns A string containing the full prompt for the AI.
 */
function generatePrompt(link: string): string {
  return `
    You are an expert car market analyst AI. Your task is to simulate a full analysis pipeline for a given car listing URL. You will act as a scraper, a price prediction model, a defect analyzer, and a scoring engine, all in one.

    Analyze the following car listing URL: ${link}

    Follow these steps precisely:

    1.  **Infer Car Identity**: From the URL, determine the likely make and model of the car.

    2.  **Simulate Scraped Data**: Generate a realistic and plausible set of data for this car. Do NOT use placeholder values.
        -   **title**: e.g., "Dacia Logan 1.5 dCi Laureate"
        -   **price**: A realistic price in Euros for this car model, year, and mileage in the Romanian market.
        -   **year**: A realistic manufacturing year.
        -   **kilometers**: Realistic mileage for the year.
        -   **power**: Engine power in HP.
        -   **fuel**: 'Petrol', 'Diesel', 'Electric', or 'Hybrid'.
        -   **description**: A short, 2-3 sentence ad description. If you decide to add an 'accident' flag later, make sure the description contains a keyword like "ușor lovit," "vopsit," or "airbag."

    3.  **Simulate Price Prediction**: Generate a \`predictedPrice\`. This should be close to the \`price\` you just generated, but with a slight, realistic variation (e.g., +/- 5-20%).

    4.  **Analyze for Defects & Flags**: Based on the data you generated, identify defects and flags according to these strict rules:
        -   **defects[]**: Choose zero or more from: [timing_chain, egr, dpf, clutch, suspension, turbo, injectors]. Base this on common issues for the inferred car model and hints in the description you wrote.
        -   **flags[]**: Choose zero or more from: [odo_rollback, accident, high_price, low_price].
            -   \`odo_rollback\`: Add this flag if the kilometers are suspiciously low for the car's age (e.g., a 10-year-old car with only 50,000 km).
            -   \`accident\`: Add this flag ONLY if the description you wrote contains words suggesting an accident (e.g., "vopsit," "lovit," "airbag").
            -   \`high_price\`: Add this flag if \`price\` is more than 15% higher than the \`predictedPrice\`.
            -   \`low_price\`: Add this flag if \`price\` is more than 15% lower than the \`predictedPrice\`.

    5.  **Calculate Score**: Compute the final score using this exact formula:
        \`score = 100 - (15 * Math.abs(price - predictedPrice) / predictedPrice) - (10 * number of flags) - (5 * number of defects)\`
        The final score must be clamped between 0 and 100 (e.g., if it's negative, make it 0; if over 100, make it 100). Round to the nearest integer.

    6.  **Return JSON**: Output a single, valid JSON object that adheres to the provided schema. Do not include any other text, explanations, or markdown formatting.
  `;
}

/**
 * A simple, browser-safe hash function to generate a unique ID from a string.
 * Replaces the Node.js crypto module.
 * @param s The string to hash.
 * @returns An 8-character hexadecimal hash string.
 */
const simpleHash = (s: string): string => {
  let hash = 0;
  for (let i = 0; i < s.length; i++) {
    const char = s.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return 'id' + Math.abs(hash).toString(16).slice(0, 8);
};

/**
 * Analyzes a list of car URLs by calling the Gemini API with a complex simulation prompt.
 * @param links An array of car listing URLs.
 * @returns A promise that resolves to the full analysis result.
 */
export async function analyzeCars(links: string[]): Promise<AnalysisResult> {
    try {
        const analysisPromises = links.map(async (link) => {
            const prompt = generatePrompt(link);

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    responseMimeType: 'application/json',
                    responseSchema: carAnalysisSchema,
                },
            });
            
            const carDataJson = JSON.parse(response.text);

            // Sanitize and format the AI's response to match our strict types.
            const carData: CarData = {
                id: simpleHash(link),
                link: link,
                title: String(carDataJson.title),
                price: Number(carDataJson.price),
                predictedPrice: Number(carDataJson.predictedPrice),
                year: Number(carDataJson.year),
                kilometers: Number(carDataJson.kilometers),
                power: Number(carDataJson.power),
                fuel: carDataJson.fuel as FuelType,
                defects: (carDataJson.defects || []) as string[],
                flags: (carDataJson.flags || []) as string[],
                score: Math.round(Number(carDataJson.score)),
            };
            return carData;
        });

        const table = await Promise.all(analysisPromises);

        if (table.length === 0) {
            throw new Error("No cars could be analyzed.");
        }

        // Sort by score descending to find the winner.
        table.sort((a, b) => b.score - a.score);

        return { winner: table[0], table };

    } catch (error) {
        console.error("Error during car analysis:", error);
        if (error instanceof Error && error.message.includes('API_KEY')) {
            throw new Error("Invalid API Key. Please check your .env file.");
        }
        if (error instanceof Error && error.message.includes('json')) {
             throw new Error("The AI returned an invalid response. Please try again.");
        }
        throw new Error("Failed to analyze car data. The AI may be busy. Please try again shortly.");
    }
}