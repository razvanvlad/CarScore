// FIX: Changed import to use qualified express types and avoid collision with global DOM types.
import express, { Express } from 'express';
import cors from 'cors';
import puppeteer from 'puppeteer';
import { GoogleGenAI, Type } from "@google/genai";

// FIX: Add Express type annotation.
const app: Express = express();
const port = 3001;

app.use(cors());
app.use(express.json());

// --- GEMINI AI SETUP ---
const apiKey = process.env.API_KEY;
if (!apiKey) {
    console.error("FATAL: API_KEY environment variable is not set.");
    process.exit(1);
}
const ai = new GoogleGenAI({ apiKey });

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        defects: {
            type: Type.ARRAY,
            items: {
                type: Type.STRING,
                enum: ['timing_chain', 'egr', 'dpf', 'clutch', 'suspension', 'turbo', 'injectors']
            }
        },
        flags: {
            type: Type.ARRAY,
            items: {
                type: Type.STRING,
                enum: ['accident']
            }
        }
    },
    required: ['defects', 'flags']
};

// --- SCRAPING LOGIC ---
async function scrapeOlx(url: string): Promise<any> {
    console.log(`Scraping URL: ${url}`);
    const browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5..0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
    
    await page.goto(url, { waitUntil: 'networkidle2' });

    const carData = await page.evaluate(() => {
        const title = document.querySelector('h1[data-cy="adPage-title"]')?.textContent?.trim() || '';
        const priceText = document.querySelector('strong[data-cy="adPage-price-value"]')?.textContent?.trim() || '0';
        const description = document.querySelector('div[data-cy="adPage-description-section"]')?.textContent?.trim() || '';
        
        const details: { [key: string]: string } = {};
        document.querySelectorAll('ul.css-1r0si1e li.css-b5m1rv').forEach(item => {
            const text = item.textContent || '';
            const separatorIndex = text.indexOf(':');
            if (separatorIndex > -1) {
                const key = text.substring(0, separatorIndex).trim();
                const value = text.substring(separatorIndex + 1).trim();
                if (key && value) { // Ensure both key and value have content after trimming
                    details[key] = value;
                }
            }
        });

        return { title, priceText, description, details };
    });

    await browser.close();

    // --- DATA CLEANING ---
    const price = parseInt(carData.priceText.replace(/\D/g, ''), 10);
    const year = parseInt(carData.details['An de fabricatie'] || '0', 10);
    const kilometers = parseInt((carData.details['Kilometraj'] || '0').replace(/\D/g, ''), 10);
    const power = parseInt((carData.details['Putere'] || '0').replace(/\D/g, ''), 10);
    const fuel = (carData.details['Combustibil'] || 'Unknown') as 'Petrol' | 'Diesel' | 'Hybrid' | 'Electric';

    return {
        title: carData.title,
        price,
        year,
        kilometers,
        power,
        fuel,
        description: carData.description.substring(0, 4000) // Limit description size for AI
    };
}


// --- API ENDPOINT ---
// FIX: Used qualified express.Request and express.Response to specify handler parameter types.
app.post('/analyze', async (req: express.Request, res: express.Response) => {
    const { links: rawLinks } = req.body;
    if (!rawLinks || !Array.isArray(rawLinks) || rawLinks.length === 0) {
        return res.status(400).json({ error: 'Please provide an array of links.' });
    }

    // FIX: Filter out any non-string or empty values from the links array to prevent errors.
    const links = rawLinks.filter((link): link is string => typeof link === 'string' && link.trim() !== '');

    if (links.length === 0) {
        return res.status(400).json({ error: 'No valid links provided.' });
    }

    try {
        const analysisPromises = links.map(async (link) => {
            const scrapedData = await scrapeOlx(link);
            const { description, ...restOfData } = scrapedData;

            // Step 1: Get AI-based analysis (defects, flags)
            const prompt = `
                Based on the following Romanian car ad description, identify potential mechanical defects and signs of an accident.
                - For defects, choose from: [timing_chain, egr, dpf, clutch, suspension, turbo, injectors].
                - For flags, add 'accident' ONLY if the text mentions words like "lovit", "accident", "vopsit", "airbag".
                Description: "${description}"

                Return ONLY a valid JSON object matching the schema.
            `;
            const aiResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    responseMimeType: 'application/json',
                    responseSchema: analysisSchema
                }
            });
            const aiAnalysis = JSON.parse(aiResponse.text);

            // Step 2: Simulate price prediction (replace with real BQ ML call later)
            const priceVariation = (Math.random() - 0.5) * 0.2; // +/- 10%
            const predictedPrice = Math.round(scrapedData.price * (1 + priceVariation));

            // Step 3: Add rule-based flags
            const flags = [...aiAnalysis.flags];
            if (scrapedData.price > predictedPrice * 1.15) flags.push('high_price');
            if (scrapedData.price < predictedPrice * 0.85) flags.push('low_price');

            // Step 4: Calculate score
            const pricePenalty = 15 * Math.abs(scrapedData.price - predictedPrice) / predictedPrice;
            const flagPenalty = 10 * flags.length;
            const defectPenalty = 5 * aiAnalysis.defects.length;
            let score = 100 - pricePenalty - flagPenalty - defectPenalty;
            score = Math.round(Math.max(0, Math.min(100, score)));

            return {
                ...restOfData,
                id: link,
                link,
                predictedPrice,
                defects: aiAnalysis.defects,
                flags,
                score
            };
        });

        const table = await Promise.all(analysisPromises);
        table.sort((a, b) => b.score - a.score);
        
        res.json({ winner: table[0], table });

    } catch (error) {
        console.error('An error occurred during analysis:', error);
        res.status(500).json({ error: 'Failed to analyze cars.' });
    }
});

app.listen(port, () => {
    console.log(`CarScore backend listening on http://localhost:${port}`);
});