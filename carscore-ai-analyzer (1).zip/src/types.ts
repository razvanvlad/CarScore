export type FuelType = 'Petrol' | 'Diesel' | 'Electric' | 'Hybrid';

export interface CarData {
  id: string;
  link: string;
  title: string;
  price: number;
  predictedPrice: number;
  year: number;
  kilometers: number;
  power: number; // in HP
  fuel: FuelType;
  defects: string[];
  flags: string[];
  score: number;
}

export interface AnalysisResult {
  winner: CarData;
  table: CarData[];
}