import { AnalysisResult } from '../types';

const BACKEND_URL = 'http://localhost:3001/analyze';

/**
 * Sends a list of car URLs to the local backend server for scraping and analysis.
 * @param links An array of car listing URLs.
 * @returns A promise that resolves to the full analysis result from the backend.
 */
export async function analyzeCars(links: string[]): Promise<AnalysisResult> {
  try {
    const response = await fetch(BACKEND_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ links }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'An error occurred on the server.');
    }

    const results = await response.json();
    return results;
  } catch (error) {
    console.error("Error communicating with backend:", error);
    if (error instanceof TypeError) {
         throw new Error("Cannot connect to the backend. Is the server running?");
    }
    throw error; // Re-throw the error to be caught by the UI
  }
}
