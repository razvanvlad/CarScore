
import React from 'react';
import { CarData } from '../types';
import { CrownIcon } from './icons/CrownIcon';
import FlagChip from './FlagChip';

interface WinnerCardProps {
  car: CarData;
}

const WinnerCard: React.FC<WinnerCardProps> = ({ car }) => {
  return (
    <div className="bg-gradient-to-br from-purple-900 to-gray-800 p-6 rounded-xl border-2 border-purple-400 shadow-2xl relative overflow-hidden">
      <div className="absolute -top-4 -right-4 text-purple-400 opacity-20">
        <CrownIcon className="w-32 h-32" />
      </div>
      <div className="relative z-10">
        <div className="flex items-center gap-3">
          <CrownIcon className="text-yellow-400 w-8 h-8" />
          <h2 className="text-2xl font-bold text-white">Top Scorer</h2>
        </div>
        <p className="text-lg text-purple-300 mt-1">{car.title}</p>

        <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="bg-gray-900/50 p-3 rounded-lg">
            <div className="text-3xl font-bold text-green-400">{car.score}<span className="text-lg">/100</span></div>
            <div className="text-sm text-gray-400">CarScore</div>
          </div>
          <div className="bg-gray-900/50 p-3 rounded-lg">
            <div className="text-3xl font-bold">{car.price.toLocaleString('ro-RO')}€</div>
            <div className="text-sm text-gray-400">Price</div>
          </div>
          <div className="bg-gray-900/50 p-3 rounded-lg">
            <div className="text-3xl font-bold">{car.year}</div>
            <div className="text-sm text-gray-400">Year</div>
          </div>
          <div className="bg-gray-900/50 p-3 rounded-lg">
            <div className="text-3xl font-bold">{(car.kilometers / 1000).toFixed(0)}k</div>
            <div className="text-sm text-gray-400">Kilometers</div>
          </div>
        </div>
        
        {(car.defects.length > 0 || car.flags.length > 0) && (
          <div className="mt-4">
            <h4 className="text-md font-semibold text-gray-300 mb-2">Potential Issues:</h4>
            <div className="flex flex-wrap gap-2">
              {car.defects.map(defect => <FlagChip key={defect} text={defect} type="defect" />)}
              {car.flags.map(flag => <FlagChip key={flag} text={flag} type="flag" />)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WinnerCard;
